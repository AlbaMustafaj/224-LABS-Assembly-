 int fourthDig,thirdDig,secondDig,firstDig;  //digits to be displayed in 7seg
int startNum;   //first number
int secondNum;  //second number
int fibNr;      //variable which will keep the sequence
int slowTemp;       // temporary needed to make execution slower and visible


int dispNr;        //which digit will be represented

void setNUM(int dispNr){ //helper function for the configurations of each digit
 if (dispNr == 9) {
  PORTD = 0b01101111;
 }
 else if (dispNr == 8){
  PORTD = 0b01111111;
 }
 else if (dispNr == 7) {
  PORTD = 0b00000111;
 }
 else if (dispNr == 6) {
  PORTD = 0b01111101;
 }
 else if (dispNr == 5) {
  PORTD = 0b01101101;
 }
 else if (dispNr == 4) {
  PORTD = 0b01100110;
 }
 else if (dispNr == 3) {
  PORTD = 0b01001111;
 }
 else if (dispNr == 2) {
  PORTD = 0b01011011;
 }
 else if (dispNr == 1) {
  PORTD = 0b00000110;
 }
 else{
  PORTD = 0b00111111;
 }

}
 int a,b;
int modulus(int number){    //compute the modulus of a number with 10
    a = number / 10;
    b = a * 10;
    return number - b;     //modulus

}
void main() {
     startNum = 0;   //first number
     secondNum = 1;  //second number
     fibNr = 0;      //variable which will keep the sequence
     TRISD = 0;   //output
     TRISG = 0;   //output
     do{

        fibNr= startNum + secondNum;   //next number is the sum of the previous two
        if (fibNr == 6765){            //if the 20th number is reached
           startNum = 0;               //start from the beginnig
           secondNum = 1;
        }
        else{
             secondNum = startNum;    //starNum becomes second number and
             startNum = fibNr;        //the new startNr nr is the sum of previous two
        }
        firstDig = modulus(fibNr);   //get first digit
        fibNr = fibNr / 10;
        secondDig = modulus(fibNr);  //get second digit
        fibNr = fibNr / 10;
        thirdDig = modulus(fibNr);   //get third digit
        fibNr = fibNr / 10;
        fourthDig = modulus(fibNr);  //get fourth digit
        for (slowTemp  = 0; slowTemp < 300; slowTemp++){    //run the loop to slow down the result so it becomes visible

         setNUM(firstDig);          //first nr in 7seg
         PORTG = 0x00b0;
         Delay_ms(1);

         setNUM(secondDig);        //second nr in 7seg
         PORTG = 0x0040;
         Delay_ms(1);

         setNUM(thirdDig);        //third nr in 7seg
         PORTG = 0x0002;
         Delay_ms(1);

         setNUM(fourthDig);       //fourth nr in 7seg
         PORTG = 0x0001;
         Delay_ms(1);
        }
     }while(1);
}