//Part 2a- 8 bit binary counter
//The following code performs binary counting from left to right and right to left.
//A helper function swapBits is used  in counting from right to left
bit temp;    //declared as global to be used in swapBits function

void swapBits() {        //helper function to swap the first and second nibles of the counter
    temp = PORTDbits.RD4;
    PORTDbits.RD4 = PORTDbits.RD3;        //swap 4th and 3rd bit
    PORTDbits.RD3 = temp;
    temp = PORTDbits.RD5;
    PORTDbits.RD5 = PORTDbits.RD2;       //swap 5th and 2nd bit
    PORTDbits.RD2 = temp;
    temp = PORTDbits.RD6;
    PORTDbits.RD6 = PORTDbits.RD1;      //swap 6th and 1st bit
    PORTDbits.RD1 = temp;
    temp = PORTDbits.RD7;
    PORTDbits.RD7 = PORTDbits.RD0;       //swap 7th and 0th bit
    PORTDbits.RD0 = temp;
}

void main() {

     // PORTA = 0xffff;                  //all leds are off
      TRISA=1;                         //A is chosen as input
      TRISD=0;                         //D is chosen as output
      while (1)  {

      if ( PORTAbits.RA0 == PORTAbits.RA1 ) {     //if both buttons are pressed or not in the same time, the leds are all off
          PORTD= 0xffff;
      }
      else if (!PORTAbits.RA0){       //if we chose left to right
           if (PORTAbits.RA2 == PORTAbits.RA3) { //if both speeding buttons are pushed
               PORTD--;
               Delay_ms(500);                                                         //it will execute every half second
           }
          else if(!PORTAbits.RA2){ // if the counting fast button is pushed
              PORTD--;
              Delay_ms(300);      // the speed is 300 ms(less then half a second)
          }
          else if ( !PORTAbits.RA3){ //if counting slow button is pushed
             PORTD--;
             Delay_ms(700);          //the speed is 700ms (more than half a second)
          }
          else {                     // serves as default: if none of these cases
            PORTD--;
            Delay_ms(500);          //  the default speed is 500ms (half a second)
          }
      }

      else if (!PORTAbits.RA1){    //if right to left is chosen
           if (PORTAbits.RA2 == PORTAbits.RA3) {  //if both speeding buttons are pushed
             Delay_ms(500);                                                             //it will execute every half second
              swapBits();                                                               //swap first and second nible
              PORTD--;                                                                  // perform counting
              swapBits();                                                               //swap again to avoid dublication
          }
          else if(!PORTAbits.RA2) {   // if the counting fast button is pushed
              Delay_ms(300);          // the speed is 300 ms(less then half a second)
              swapBits();             //swap first and second nible
              PORTD--;                // perform counting
              swapBits();             //swap again to avoid dublication
          }
          else if (!PORTAbits.RA3){   // if the counting slow button is pushed
              Delay_ms(700);          // the speed is 700 ms(more then half a second)
              swapBits();             //swap first and second nible
              PORTD--;                // perform counting
              swapBits();             //swap again to avoid dublication
          }
          else {                      // serves as default: if none of these cases
              Delay_ms(500);          // the default speed is 500ms (half a second)
              swapBits();
              PORTD--;
              swapBits();
          }
       }

     }

 }

